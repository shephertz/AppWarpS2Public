//
//  MasterClient.h
//  AppWarp_Project
//
//  Created by Nitin Gupta on 14/05/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MasterChannel;
@class WarpResponse;
@class WarpNotifyMessage;

@interface MasterClient : NSObject
{
    
}

@property (nonatomic, retain) MasterChannel *masterChannel;

/**
 * Gives the singleton instance of MasterClient (if initialized with keys).
 * If not initialized, this will throw an Exception
 * @return MasterClient
 */
+(instancetype)getInstance;

/**
 * This should be your first API call to MasterClient. This will instantiate
 * the MasterClient singleton and set it up to be used with the keys provided
 * in params. Calling it more than once will return error.
 * @param masterServerHost : ip address where master server is running.
 * @param masterServerPort : port number on which master server is running.
 * @return
 */

+(BOOL)initMasterClientWithHost:(NSString*)masterServerHost port:(int)masterServerPort;

/**
 * Send a request to master server.
 * Result of this API call will be received in onConnectDone of the MasterRequestListener.
 * @returns
 * void
 */
-(void)connect;

/**
 * Send a request to master server.
 * Result of this API call will be received in onDisconnectDone of the MasterRequestListener.
 * @returns
 * void
 */
- (void)disconnect;

/**
 * Gives the current connection state of the client as
 *
 * @return
 */
-(int)getConnectionState;

/**
 * Send a request to master server. 
 * Result of this API call will be received in onGetAllServerDone of the MasterRequestListener.
 * @returns
 * void
 */
- (void)getAllServers;

/**
 * Sends a custom chat message to the master server.
 * Incoming custom message notification will provided in onCustomMessageReceived of MasterRequestLister
 *  @param
 *  message: message to be sent to MasterServer
 *  @returns
 *  void
 */
- (void)sendCustomMessage:(NSData *)message;

/**
 *  @param
 *  aListener: a Listener to Master Client .
 *  @return
 *  void
 */
- (void)addMasterRequestListener:(id)aListener;

/**
 * Gives the current connection state of the client as
 * @return
 */
-(void)onResponse:(WarpResponse*)response;
-(void)onNotify:(WarpNotifyMessage*)notify;
-(void)onConnect:(Byte)value;


@end
