//
//  AllServerEvent.h
//  AppWarp_Project
//
//  Created by Nitin Gupta on 14/05/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WarpResponse;

@interface AllServerEvent : NSObject {

}

@property (nonatomic, retain) NSMutableArray *serverList;
@property Byte result;

/**
 * @param response
 * @return
 */
+(instancetype)buildAllServerEvent:(WarpResponse *)response;

@end
