//
//  MasterChannel.h
//  AppWarp_Project
//
//  Created by Nitin Gupta on 14/05/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MasterChannel : NSObject <NSStreamDelegate> {
    NSInputStream   *inputStream;
    NSOutputStream  *outputStream;
}

@property (nonatomic, retain) NSString *host;
@property (nonatomic, retain) NSMutableArray *list;
@property (nonatomic, assign) int port;
@property (nonatomic, retain) NSMutableData     *incompleteData;
@property (nonatomic, assign) BOOL              waitingForData;

/**
 * Initializing and Connecting Master Channel
 * @return void
 */
- (void)initMasterChannelCommunication;

/**
 * Sending Data via Master Channel
 * @return void
 */
- (void)sendData:(NSData*)data;

/**
 * Disconnecting Master Channel
 * @return void
 */
- (void)disconnect;

@end
