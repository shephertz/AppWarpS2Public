//
//  Address.h
//  AppWarp_Project
//
//  Created by Shephertz Technologies Pvt Ltd on 10/07/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Address : NSObject
{
    
}
@property(nonatomic,retain) NSString *host;
@property(nonatomic,assign) int port;

@end
