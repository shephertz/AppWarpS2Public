//
//  GameServer.h
//  AppWarp_Project
//
//  Created by Shephertz Technologies Pvt Ltd on 10/07/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Address.h"

@interface GameServer : NSObject

-(id)initWithAddress:(Address*)_address andPort:(NSMutableArray*)_appKeys;
-(Address*)getAddress;
-(NSMutableArray*)getAppKeys;
@end
