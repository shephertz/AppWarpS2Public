//
//  MasterRequestListener.h
//  AppWarp_Project
//
//  Created by Nitin Gupta on 14/05/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AllServerEvent.h"
#import "ConnectEvent.h"

@protocol MasterRequestListener <NSObject>

@required
/**
 * Invoked in response to a connect request.
 * @param event
 */
-(void)onMasterConnectDone:(ConnectEvent*)event;

/**
 * Invoked in response to a disconnect request.
 * @param event
 */
-(void)onMasterDisconnectDone:(ConnectEvent*)event;
/**
 * Invoked in response of getAllServers request
 * @param AllServerEvent
 */
-(void) onGetAllServerDone:(AllServerEvent*)event;

/**
 * Invoke when AppWarpS2 client receive custom message from MasterServer
 * @param message
 */
-(void)onCustomMessageReceived:(NSData*)message;

@end
